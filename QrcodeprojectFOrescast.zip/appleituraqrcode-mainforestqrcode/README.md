# appleituraqrcode
