package com.example.qrcodeproject.api;

import com.example.qrcodeproject.model.Parametros;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;


public interface TemService {

// Rota API
    @GET("forecast?latitude=52.52&longitude=13.41")

    Call<Parametros> Forecast();
}
